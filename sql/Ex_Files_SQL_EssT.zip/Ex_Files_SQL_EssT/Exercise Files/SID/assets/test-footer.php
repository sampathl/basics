
<div class="footer">
<p class="copyright">
    Version <?php echo VERSION ?><br />
    Copyright &copy; 2009-2010 The BearHeart Group LLC
</p>

</body>
</heml>
