
<div class="footer">
<p class="copyright">
    <?php echo $SID['DBVERSION'] ?>
    &middot;
    SID <?php echo VERSION ?>
    &middot;
    PHP <?php echo phpversion(); ?><br />
    Copyright &copy; 2009&ndash;2018 The BearHeart Group LLC
</p>

</body>
</html>
