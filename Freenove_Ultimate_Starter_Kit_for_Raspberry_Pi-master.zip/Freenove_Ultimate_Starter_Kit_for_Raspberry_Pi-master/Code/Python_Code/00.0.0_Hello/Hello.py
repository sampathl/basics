#!/usr/bin/env python3
########################################################################
# Filename    : Hello.py
# Description : Print "Hello World!".
# auther      : www.freenove.com
# modification: 2019/12/27
########################################################################

def Hello():
	print('Hello World!')

Hello()
